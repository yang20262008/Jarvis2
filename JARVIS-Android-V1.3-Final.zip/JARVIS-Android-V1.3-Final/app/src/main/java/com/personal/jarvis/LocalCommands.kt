package com.personal.jarvis

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** 本地指令的解析结果。 */
sealed class LocalAction {
    /** 不是本地指令，交给 AI。 */
    data object None : LocalAction()

    /** 打开操作记录。 */
    data object OpenLog : LocalAction()

    /** 只读查询（时间、电量等），直接回答，不需要确认。 */
    data class Reply(val text: String, val logLabel: String) : LocalAction()

    /** 会离开 JARVIS 的操作（打开应用、拨号界面等），必须用户确认后才执行。 */
    data class NeedConfirm(
        val description: String,
        val intent: Intent,
        val logLabel: String
    ) : LocalAction()
}

/**
 * 手机本地指令：在手机上直接处理，不上传给 AI。
 * 只有短句才会被当作指令，长句一律交给 AI，避免误触发。
 */
object LocalCommands {
    private const val MAX_LEN = 24

    fun interpret(context: Context, raw: String): LocalAction {
        val t = raw.replace(Regex("[\\s，。！？、,.!?\\-]"), "")
        if (t.isEmpty() || t.length > MAX_LEN) return LocalAction.None

        if (t.contains("操作记录") || t.contains("查看记录") || t.contains("操作日志")) {
            return LocalAction.OpenLog
        }
        val open = Regex("^(请)?(帮我)?(打开|启动|运行)(.+)$").find(t)
        if (open != null) return openTarget(context, open.groupValues[4])

        if (t.contains("电量")) return batteryReply(context)
        if (listOf("几点", "现在时间", "当前时间", "今天几号", "今天日期", "星期几", "今天周几").any { t.contains(it) }) {
            return timeReply()
        }

        if (listOf("打电话", "拨号", "拨打", "呼叫").any { t.contains(it) }) return dial(t)
        return LocalAction.None
    }

    private fun timeReply(): LocalAction {
        val now = LocalDateTime.now()
        val text = now.format(DateTimeFormatter.ofPattern("yyyy年M月d日 EEEE HH点mm分", Locale.SIMPLIFIED_CHINESE))
        return LocalAction.Reply("现在是$text。", "查询时间")
    }

    private fun batteryReply(context: Context): LocalAction {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        if (level < 0 || scale <= 0) return LocalAction.Reply("暂时读取不到电量信息。", "查询电量")
        val percent = level * 100 / scale
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return LocalAction.Reply("当前电量百分之$percent${if (charging) "，正在充电" else ""}。", "查询电量")
    }

    private fun dial(t: String): LocalAction {
        val number = Regex("\\+?[0-9]{3,15}").find(t)?.value
            ?: return LocalAction.Reply(
                "目前只支持说出号码来拨号，例如“拨号 10086”。按联系人名字拨号需要通讯录授权，后续版本再支持。",
                "拨号：缺少号码"
            )
        return LocalAction.NeedConfirm(
            "打开拨号界面，号码 $number。不会自动拨出，需要你自己点拨号键。",
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")),
            "打开拨号界面 $number"
        )
    }

    private fun norm(s: String) = s.lowercase(Locale.ROOT).replace(" ", "")

    private fun openTarget(context: Context, rawName: String): LocalAction {
        if (rawName in setOf("设置", "系统设置", "手机设置")) {
            return LocalAction.NeedConfirm("打开系统设置。", Intent(Settings.ACTION_SETTINGS), "打开系统设置")
        }
        if (rawName in setOf("拨号", "拨号界面", "拨号盘", "电话", "打电话")) {
            return LocalAction.NeedConfirm("打开拨号界面，不会自动拨出。", Intent(Intent.ACTION_DIAL), "打开拨号界面")
        }

        var name = rawName
        for (suffix in listOf("应用", "软件", "app", "App", "APP")) name = name.removeSuffix(suffix)
        val key = norm(name)
        if (key.isEmpty()) return LocalAction.None

        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }

        val exact = apps.filter { norm(it.first) == key }
        val matches = if (exact.isNotEmpty()) exact else apps.filter { norm(it.first).contains(key) }

        if (matches.isEmpty()) {
            // 名字很长，更像是普通聊天内容，交给 AI。
            return if (name.length <= 8) {
                LocalAction.Reply("没有找到名为“$name”的应用。", "打开应用：未找到 $name")
            } else LocalAction.None
        }
        if (exact.isEmpty() && matches.size > 1) {
            val names = matches.take(4).joinToString("、") { it.first }
            return LocalAction.Reply("找到多个应用：$names。请说得更具体一些。", "打开应用：名称不明确 $name")
        }

        val (label, pkg) = matches.first()
        val launch = pm.getLaunchIntentForPackage(pkg)
            ?: return LocalAction.Reply("无法打开“$label”。", "打开应用：失败 $label")
        return LocalAction.NeedConfirm("打开应用“$label”。", launch, "打开应用 $label")
    }
}
