package com.personal.jarvis

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * Android 端只连接你自己的 HTTPS 后端。
 * AI API Key 必须留在后端环境变量中，不能放进 APK。
 */
object AiClient {
    private fun cleanBase(backendUrl: String): String {
        val base = backendUrl.trim().trimEnd('/')
        require(base.startsWith("https://")) { "为了保护通信安全，后端地址必须使用 HTTPS。" }
        return base
    }

    /** 网络类错误自动重试一次，并转换成中文提示。 */
    suspend fun chat(
        backendUrl: String,
        accessToken: String,
        conversation: List<ChatMessage>,
        speakable: Boolean = false
    ): String {
        return try {
            try {
                chatOnce(backendUrl, accessToken, conversation, speakable)
            } catch (e: IOException) {
                delay(800)
                chatOnce(backendUrl, accessToken, conversation, speakable)
            }
        } catch (e: UnknownHostException) {
            throw IllegalStateException("找不到服务器，请检查网络、VPN 和后端地址是否正确。")
        } catch (e: SocketTimeoutException) {
            throw IllegalStateException("连接超时，请稍后重试。")
        } catch (e: IOException) {
            throw IllegalStateException("网络连接失败，请检查网络和后端服务。")
        }
    }

    /** 测试后端是否在线（GET /health，不会发送任何对话内容）。 */
    suspend fun checkHealth(backendUrl: String): String = withContext(Dispatchers.IO) {
        val base = cleanBase(backendUrl)
        val connection = (URL("$base/health").openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 10000
        }
        try {
            val status = connection.responseCode
            if (status !in 200..299) throw IllegalStateException("后端返回 HTTP $status")
            "后端在线"
        } catch (e: UnknownHostException) {
            throw IllegalStateException("找不到服务器，请检查地址、网络和 VPN。")
        } catch (e: SocketTimeoutException) {
            throw IllegalStateException("连接超时。")
        } catch (e: IOException) {
            throw IllegalStateException("无法连接后端。")
        } finally {
            connection.disconnect()
        }
    }

    private suspend fun chatOnce(
        backendUrl: String,
        accessToken: String,
        conversation: List<ChatMessage>,
        speakable: Boolean
    ): String = withContext(Dispatchers.IO) {
        val base = cleanBase(backendUrl)
        val connection = (URL("$base/api/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Jarvis-Token", accessToken)
        }

        try {
            val messages = JSONArray()
            // 只发送最近 12 条对话，避免不必要地上传过多内容。
            conversation.takeLast(12).forEach { item ->
                messages.put(
                    JSONObject()
                        .put("role", if (item.fromUser) "user" else "assistant")
                        .put("content", item.text)
                )
            }

            // speakable=true 表示回答会被朗读，后端据此要求 AI 用口语化、无 Markdown 的短句回答。
            val body = JSONObject()
                .put("messages", messages)
                .put("speakable", speakable)
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (status !in 200..299) {
                val serverMessage = runCatching {
                    JSONObject(responseText).optString("error")
                }.getOrNull().orEmpty()
                throw IllegalStateException(
                    if (serverMessage.isNotBlank()) serverMessage else "服务器返回错误（HTTP $status）"
                )
            }

            val json = JSONObject(responseText)
            json.optString("reply").takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("服务器没有返回有效回答。")
        } finally {
            connection.disconnect()
        }
    }
}
