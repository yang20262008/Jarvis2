package com.personal.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** 操作记录中的一条。 */
data class LogEntry(val time: Long, val action: String, val result: String)

/** 操作记录：只保存在本机，最多 100 条。 */
object ActionLog {
    private const val MAX = 100
    private fun prefs(c: Context) = c.getSharedPreferences("jarvis_log", Context.MODE_PRIVATE)

    /** 最新的在前。 */
    fun all(c: Context): List<LogEntry> {
        val arr = runCatching { JSONArray(prefs(c).getString("log", "[]")) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let {
                LogEntry(it.optLong("t"), it.optString("a"), it.optString("r"))
            }
        }.reversed()
    }

    fun add(c: Context, action: String, result: String) {
        val arr = runCatching { JSONArray(prefs(c).getString("log", "[]")) }.getOrDefault(JSONArray())
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("a", action).put("r", result))
        val start = (arr.length() - MAX).coerceAtLeast(0)
        val trimmed = JSONArray()
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs(c).edit().putString("log", trimmed.toString()).apply()
    }

    fun clear(c: Context) {
        prefs(c).edit().remove("log").apply()
    }
}

/** 对话记录：只保存在本机，最多 50 条，可在设置里清空。 */
object ChatStore {
    private const val MAX = 50
    private fun prefs(c: Context) = c.getSharedPreferences("jarvis_chat", Context.MODE_PRIVATE)

    fun load(c: Context): List<ChatMessage> {
        val arr = runCatching { JSONArray(prefs(c).getString("chat", "[]")) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { ChatMessage(it.optString("x"), it.optBoolean("u")) }
        }.filter { it.text.isNotBlank() }
    }

    fun save(c: Context, messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.takeLast(MAX).forEach {
            arr.put(JSONObject().put("x", it.text).put("u", it.fromUser))
        }
        prefs(c).edit().putString("chat", arr.toString()).apply()
    }

    fun clear(c: Context) {
        prefs(c).edit().remove("chat").apply()
    }
}
