package com.personal.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Blue = Color(0xFF77B7FF)
private val Page = Color(0xFF0B1220)
private val Panel = Color(0xFF152238)
private val Muted = Color(0xFF9AAAC0)

data class ChatMessage(val text: String, val fromUser: Boolean)

private const val LAST_UTTERANCE = "jarvis_last"

private const val WELCOME =
    "你好，我是 JARVIS。你可以打字或点麦克风对我说话。\n" +
    "我能在手机上直接做：问时间、查电量、打开应用（如“打开微信”）、打开拨号界面（如“拨号 10086”）、查看操作记录。" +
    "打开应用和拨号前都会先请你确认。其他问题会交给 AI。首次使用请先点右上角设置，填写后端地址。"

/** 去掉 Markdown 符号、代码块和网址，让朗读更自然。 */
private fun cleanForSpeech(text: String): String =
    text
        .replace(Regex("```[\\s\\S]*?```"), "（代码内容已省略）")
        .replace(Regex("\\[([^\\]]*)]\\([^)]*\\)"), "\$1")
        .replace(Regex("https?://\\S+"), "链接")
        .replace(Regex("[*#`>_~|]"), "")
        .replace(Regex("\\n{2,}"), "\n")
        .trim()

/** TextToSpeech 单次输入有长度上限，按句子切成不超过 300 字的小段依次播报。 */
private fun splitForSpeech(text: String, maxLen: Int = 300): List<String> {
    val sentences = text.split(Regex("(?<=[。！？!?；;\\n])"))
        .map { it.trim() }
        .filter { it.isNotEmpty() }
    val chunks = mutableListOf<String>()
    val buffer = StringBuilder()
    for (sentence in sentences) {
        if (buffer.isNotEmpty() && buffer.length + sentence.length > maxLen) {
            chunks.add(buffer.toString())
            buffer.clear()
        }
        if (sentence.length > maxLen) sentence.chunked(maxLen).forEach { chunks.add(it) }
        else buffer.append(sentence)
    }
    if (buffer.isNotEmpty()) chunks.add(buffer.toString())
    return chunks
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

@Composable
fun JarvisApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis_settings", 0) }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }
    var accessToken by remember { mutableStateOf(prefs.getString("access_token", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<LocalAction.NeedConfirm?>(null) }
    var showLog by remember { mutableStateOf(false) }
    var logEntries by remember { mutableStateOf(emptyList<LogEntry>()) }
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var listening by remember { mutableStateOf(false) }
    var speechStatus by remember { mutableStateOf("语音功能待命") }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var textToSpeech by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var lastReply by remember { mutableStateOf("") }
    var autoSpeak by remember { mutableStateOf(prefs.getBoolean("auto_speak", true)) }
    val scope = rememberCoroutineScope()

    var messages by remember {
        mutableStateOf(ChatStore.load(context).ifEmpty { listOf(ChatMessage(WELCOME, false)) })
    }
    LaunchedEffect(messages) { ChatStore.save(context, messages) }
    LaunchedEffect(messages.size, loading) {
        val total = messages.size + if (loading) 1 else 0
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    DisposableEffect(context) {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        } else {
            speechStatus = "当前设备没有可用的语音识别服务，仍可使用文字输入"
        }

        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            val tts = engine
            if (status == TextToSpeech.SUCCESS && tts != null) {
                val result = tts.setLanguage(Locale.SIMPLIFIED_CHINESE)
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { speaking = true }
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId == LAST_UTTERANCE) speaking = false
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { speaking = false }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { speaking = false }
                })
                if (!ttsReady) {
                    speechStatus = "手机缺少中文语音数据，回答将只显示文字（可在系统“文字转语音”设置中下载中文语音）"
                }
            } else {
                ttsReady = false
                speechStatus = "文字转语音引擎初始化失败，回答将只显示文字"
            }
        }
        textToSpeech = engine

        onDispose {
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        }
    }

    // 隐私：App 退到后台时，立即停止聆听和朗读。
    val activity = context as? ComponentActivity
    DisposableEffect(activity) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                runCatching { speechRecognizer?.cancel() }
                textToSpeech?.stop()
                listening = false
                speaking = false
            }
        }
        activity?.lifecycle?.addObserver(observer)
        onDispose { activity?.lifecycle?.removeObserver(observer) }
    }

    val recognitionIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "zh-CN")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "请说出你想对 JARVIS 说的话")
        }
    }

    DisposableEffect(speechRecognizer) {
        val recognizer = speechRecognizer
        if (recognizer != null) {
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    listening = true
                    speechStatus = "正在聆听…"
                }
                override fun onBeginningOfSpeech() {
                    speechStatus = "正在识别你的语音…"
                }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    listening = false
                    speechStatus = "正在整理识别结果…"
                }
                override fun onError(errorCode: Int) {
                    listening = false
                    speechStatus = when (errorCode) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "识别失败：没有听清，请点麦克风重试"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "识别失败：没有检测到说话声音"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "识别失败：麦克风权限不足，请在系统设置中允许"
                        SpeechRecognizer.ERROR_AUDIO -> "识别失败：麦克风录音出错"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "识别服务正忙，请稍后再试"
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "识别失败：语音识别服务网络异常"
                        SpeechRecognizer.ERROR_SERVER -> "识别失败：语音识别服务出错"
                        SpeechRecognizer.ERROR_CLIENT -> "语音识别已中断，请重试"
                        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "识别失败：手机语音服务暂不支持中文"
                        else -> "识别失败（错误码 $errorCode）"
                    }
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!spoken.isNullOrBlank()) {
                        input = spoken
                        speechStatus = "识别成功：请检查文字，确认后点发送"
                    } else {
                        speechStatus = "识别失败：没有识别到内容，请重试"
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!partial.isNullOrBlank()) input = partial
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        onDispose {
            runCatching { recognizer?.cancel() }
        }
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
        speaking = false
    }

    fun beginListening() {
        // 先停止朗读，避免麦克风把 JARVIS 自己的声音识别进去。
        stopSpeaking()
        runCatching {
            speechRecognizer?.cancel()
            speechRecognizer?.startListening(recognitionIntent)
            speechStatus = "正在启动麦克风…"
        }.onFailure {
            listening = false
            speechStatus = "无法启动语音识别，请检查手机的语音服务"
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) beginListening()
        else speechStatus = "没有麦克风权限，无法语音输入；可在系统设置中开启，或继续使用文字输入"
    }

    fun startVoiceInput() {
        if (speechRecognizer == null || !SpeechRecognizer.isRecognitionAvailable(context)) {
            speechStatus = "设备没有可用的语音识别服务，请使用文字输入"
            return
        }
        val permission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        if (permission == PackageManager.PERMISSION_GRANTED) beginListening()
        else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun stopListening() {
        runCatching { speechRecognizer?.cancel() }
        listening = false
        speechStatus = "已停止聆听"
    }

    fun speakText(raw: String) {
        val engine = textToSpeech
        if (engine == null || !ttsReady) {
            speechStatus = "当前无法朗读：手机缺少中文语音数据或引擎未就绪"
            return
        }
        val chunks = splitForSpeech(cleanForSpeech(raw))
        if (chunks.isEmpty()) return
        chunks.forEachIndexed { index, chunk ->
            val id = if (index == chunks.lastIndex) LAST_UTTERANCE else "jarvis_part_$index"
            engine.speak(
                chunk,
                if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                null,
                id
            )
        }
        speaking = true
    }

    fun restartInput() {
        // 重新输入：清空当前文字并重新开始聆听。
        input = ""
        startVoiceInput()
    }

    fun openLog() {
        logEntries = ActionLog.all(context)
        showLog = true
    }

    /** 添加一条 JARVIS 的本地回答，并按设置朗读。 */
    fun localAnswer(text: String) {
        messages = messages + ChatMessage(text, false)
        lastReply = text
        if (autoSpeak) speakText(text)
    }

    fun sendMessage() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        if (listening) stopListening()
        stopSpeaking()
        error = null

        // 1) 先尝试手机本地指令：不需要后端，也不上传内容。
        when (val local = LocalCommands.interpret(context, text)) {
            is LocalAction.Reply -> {
                messages = messages + ChatMessage(text, true)
                input = ""
                ActionLog.add(context, local.logLabel, "已完成（本地处理，未上传）")
                localAnswer(local.text)
                return
            }
            is LocalAction.NeedConfirm -> {
                messages = messages + ChatMessage(text, true)
                input = ""
                pending = local
                ActionLog.add(context, local.logLabel, "等待确认")
                return
            }
            LocalAction.OpenLog -> {
                input = ""
                openLog()
                return
            }
            LocalAction.None -> Unit
        }

        // 2) 交给真实 AI 后端。
        if (backendUrl.isBlank()) {
            error = "请先点击右上角设置，填写 HTTPS 后端地址。"
            showSettings = true
            return
        }
        val updated = messages + ChatMessage(text, true)
        messages = updated
        input = ""
        loading = true
        ActionLog.add(context, "发送给 AI", "已发送最近 ${minOf(updated.size, 12)} 条消息")
        scope.launch {
            try {
                val answer = AiClient.chat(backendUrl, accessToken, updated, speakable = autoSpeak && ttsReady)
                messages = messages + ChatMessage(answer, false)
                lastReply = answer
                if (autoSpeak) speakText(answer)
            } catch (e: Exception) {
                error = e.message ?: "连接失败，请检查网络和后端服务。"
            } finally {
                loading = false
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Page, surface = Panel)) {
        Column(
            Modifier.fillMaxSize().background(Page).statusBarsPadding()
                .navigationBarsPadding().imePadding().padding(horizontal = 18.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(42.dp).background(Color(0xFF182D4B), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Psychology, null, tint = Blue, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("JARVIS", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("PERSONAL AI ASSISTANT · V1.3 FINAL", color = Muted, fontSize = 9.sp)
                }
                IconButton(onClick = { openLog() }) {
                    Icon(Icons.Default.History, contentDescription = "操作记录", tint = Muted)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "后端设置", tint = Muted)
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(46.dp).background(Color(0xFF0E1B30), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Blue, modifier = Modifier.size(25.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            listening -> "正在聆听…"
                            loading -> "JARVIS 正在思考"
                            speaking -> "JARVIS 正在播报"
                            else -> "语音与 AI 对话已就绪"
                        },
                        color = Color.White, fontWeight = FontWeight.SemiBold
                    )
                    Text(speechStatus, color = Muted, fontSize = 11.sp)
                }
                if (loading) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                else Icon(
                    Icons.Default.Circle, null,
                    // 红点 = 麦克风正在使用；蓝点 = 正在播报；绿点 = 空闲
                    tint = when {
                        listening -> Color(0xFFFF6B6B)
                        speaking -> Blue
                        else -> Color(0xFF70D6A5)
                    },
                    modifier = Modifier.size(10.dp)
                )
            }

            Spacer(Modifier.height(14.dp))
            Text("对话记录", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { MessageBubble(it) }
                if (loading) item {
                    Text("JARVIS 正在思考…", color = Blue, fontSize = 13.sp, modifier = Modifier.padding(8.dp))
                }
            }

            error?.let {
                Surface(color = Color(0xFF4A2630), shape = RoundedCornerShape(12.dp)) {
                    Text(it, color = Color(0xFFFFC3C9), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(10.dp))
                }
                Spacer(Modifier.height(8.dp))
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { restartInput() },
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("重新输入", fontSize = 12.sp)
                }
                TextButton(
                    onClick = { if (speaking) stopSpeaking() else speakText(lastReply) },
                    enabled = speaking || lastReply.isNotBlank(),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(
                        if (speaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        null, modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (speaking) "停止播报" else "重播回答", fontSize = 12.sp)
                }
                Spacer(Modifier.weight(1f))
                TextButton(
                    onClick = {
                        autoSpeak = !autoSpeak
                        prefs.edit().putBoolean("auto_speak", autoSpeak).apply()
                        if (!autoSpeak) stopSpeaking()
                    },
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) { Text(if (autoSpeak) "自动播报：开" else "自动播报：关", fontSize = 12.sp) }
            }
            Text("语音识别结果需检查后再发送，不会自动上传", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(5.dp))
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(start = 6.dp, top = 10.dp, bottom = 10.dp),
                    singleLine = false,
                    maxLines = 3,
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Blue),
                    decorationBox = { inner ->
                        if (input.isEmpty()) Text("输入或说出你想做的事情…", color = Muted, fontSize = 13.sp)
                        inner()
                    }
                )
                IconButton(onClick = { if (listening) stopListening() else startVoiceInput() }) {
                    Icon(
                        if (listening) Icons.Default.StopCircle else Icons.Default.Mic,
                        contentDescription = if (listening) "停止聆听" else "开始语音输入",
                        tint = if (listening) Color(0xFFFF8B8B) else Blue
                    )
                }
                IconButton(onClick = { sendMessage() }, enabled = input.isNotBlank() && !loading) {
                    Icon(Icons.Default.Send, contentDescription = "发送", tint = if (input.isNotBlank() && !loading) Blue else Muted)
                }
            }
            Text(
                "麦克风仅在主动点击后启用 · 打开应用与拨号需你确认",
                color = Muted, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 9.dp)
            )
        }
    }

    if (showSettings) {
        var draft by remember(backendUrl) { mutableStateOf(backendUrl) }
        var tokenDraft by remember(accessToken) { mutableStateOf(accessToken) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("后端连接设置") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("填写你部署好的 HTTPS 后端地址。", fontSize = 13.sp)
                    OutlinedTextField(value = draft, onValueChange = { draft = it }, label = { Text("HTTPS 后端地址") }, singleLine = true)
                    OutlinedTextField(value = tokenDraft, onValueChange = { tokenDraft = it }, label = { Text("私人访问令牌") }, singleLine = true)
                    Text("这里不填写 AI API Key。", color = Muted, fontSize = 11.sp)
                    var testResult by remember { mutableStateOf("") }
                    TextButton(onClick = {
                        testResult = "正在测试…"
                        scope.launch {
                            testResult = try {
                                AiClient.checkHealth(draft)
                            } catch (e: Exception) {
                                "失败：" + (e.message ?: "无法连接")
                            }
                        }
                    }) { Text("测试后端连接") }
                    if (testResult.isNotEmpty()) Text(testResult, fontSize = 12.sp)
                    TextButton(onClick = {
                        ChatStore.clear(context)
                        messages = listOf(ChatMessage(WELCOME, false))
                        lastReply = ""
                        ActionLog.add(context, "清空对话记录", "已完成")
                        showSettings = false
                    }) { Text("清空本机对话记录") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    backendUrl = draft.trim().trimEnd('/')
                    accessToken = tokenDraft.trim()
                    prefs.edit().putString("backend_url", backendUrl).putString("access_token", accessToken).apply()
                    showSettings = false
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("取消") } }
        )
    }

    // 操作确认窗口：任何会离开 JARVIS 的操作都必须经过这里。
    pending?.let { action ->
        val cancel = {
            pending = null
            ActionLog.add(context, action.logLabel, "用户取消")
            messages = messages + ChatMessage("已取消，没有执行任何操作。", false)
        }
        AlertDialog(
            onDismissRequest = cancel,
            title = { Text("需要你确认") },
            text = { Text(action.description) },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    val ok = runCatching {
                        context.startActivity(action.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }.isSuccess
                    ActionLog.add(context, action.logLabel, if (ok) "用户已确认并执行" else "执行失败")
                    messages = messages + ChatMessage(
                        if (ok) "好的，已为你执行。" else "执行失败：系统没有响应这个操作。", false
                    )
                }) { Text("确认") }
            },
            dismissButton = { TextButton(onClick = cancel) { Text("取消") } }
        )
    }

    // 操作记录窗口。
    if (showLog) {
        AlertDialog(
            onDismissRequest = { showLog = false },
            title = { Text("操作记录") },
            text = {
                if (logEntries.isEmpty()) {
                    Text("还没有记录。")
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(logEntries) { e ->
                            Column {
                                Text(
                                    SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(e.time)),
                                    fontSize = 11.sp, color = Muted
                                )
                                Text(e.action, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(e.result, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showLog = false }) { Text("关闭") } },
            dismissButton = {
                TextButton(onClick = {
                    ActionLog.clear(context)
                    logEntries = emptyList()
                }) { Text("清空记录") }
            }
        )
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (message.fromUser) Color(0xFF24466D) else Panel,
            shape = RoundedCornerShape(
                topStart = 16.dp, topEnd = 16.dp,
                bottomStart = if (message.fromUser) 16.dp else 4.dp,
                bottomEnd = if (message.fromUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Text(message.text, color = Color.White, fontSize = 14.sp, lineHeight = 21.sp,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp))
        }
    }
}
