import http from "node:http";
import { timingSafeEqual } from "node:crypto";

const PORT = Number(process.env.PORT || 3000);
const AI_BASE_URL = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
const AI_MODEL = process.env.AI_MODEL;
const AI_API_KEY = process.env.AI_API_KEY;
const JARVIS_ACCESS_TOKEN = process.env.JARVIS_ACCESS_TOKEN;
const MAX_BODY = 64 * 1024;

// 简单限流：每个 IP 每分钟最多 30 次对话请求，防止令牌泄露后被刷。
const RATE_LIMIT = 30;
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 60000);
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 1000) {
    for (const [key, times] of hits) {
      if (times.every((t) => now - t >= 60000)) hits.delete(key);
    }
  }
  return recent.length > RATE_LIMIT;
}

function tokenMatches(provided, expected) {
  const a = Buffer.from(String(provided || ""));
  const b = Buffer.from(String(expected));
  return a.length === b.length && timingSafeEqual(a, b);
}

function send(res, status, data) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/health") {
    return send(res, 200, { ok: true, service: "jarvis-backend" });
  }

  if (req.method !== "POST" || req.url !== "/api/chat") {
    return send(res, 404, { error: "Not found" });
  }

  if (!JARVIS_ACCESS_TOKEN) {
    return send(res, 503, { error: "后端尚未配置 JARVIS_ACCESS_TOKEN。" });
  }
  const ip = req.headers["x-forwarded-for"]?.toString().split(",")[0].trim() || req.socket.remoteAddress || "unknown";
  if (rateLimited(ip)) {
    return send(res, 429, { error: "请求太频繁，请稍后再试。" });
  }
  if (!tokenMatches(req.headers["x-jarvis-token"], JARVIS_ACCESS_TOKEN)) {
    return send(res, 401, { error: "访问未授权，请检查私人访问令牌。" });
  }

  if (!AI_API_KEY || !AI_MODEL) {
    return send(res, 503, { error: "后端尚未配置 AI_API_KEY 或 AI_MODEL。" });
  }

  let raw = "";
  try {
    for await (const chunk of req) {
      raw += chunk.toString("utf8");
      if (raw.length > MAX_BODY) {
        req.destroy();
        return;
      }
    }

    const payload = JSON.parse(raw || "{}");
    if (!Array.isArray(payload.messages) || payload.messages.length === 0 || payload.messages.length > 12) {
      return send(res, 400, { error: "消息格式不正确，最多支持最近 12 条消息。" });
    }

    const messages = payload.messages.map((m) => {
      if (!["user", "assistant"].includes(m.role) || typeof m.content !== "string") {
        throw new Error("消息字段无效。");
      }
      return { role: m.role, content: m.content.slice(0, 8000) };
    });

    const speakable = payload.speakable === true;
    const SPEAKABLE_HINT =
      "本次回答会由手机语音朗读：请使用自然、口语化的简体中文，通常不超过 150 字；" +
      "不要使用 Markdown、表格、项目符号、代码块、表情符号或网址。";

    const upstream = await fetch(`${AI_BASE_URL}/chat/completions`, {
      method: "POST",
      headers: {
        "authorization": `Bearer ${AI_API_KEY}`,
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model: AI_MODEL,
        messages: [
          {
            role: "system",
            content: "你是 JARVIS，一个谨慎、清晰的私人 AI 助手。你运行在用户的安卓手机 App 中。查询时间、电量、打开应用、打开拨号界面这类手机操作由 App 在本地完成，不经过你；你自己不能操作手机，不得声称已执行未实际执行的手机操作。"
          },
          ...(speakable ? [{ role: "system", content: SPEAKABLE_HINT }] : []),
          ...messages
        ],
        temperature: 0.6
      }),
      signal: AbortSignal.timeout(55000)
    });

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      // 不把上游响应中的密钥或内部诊断信息转发给手机。
      return send(res, 502, { error: `AI 服务暂时不可用（上游 HTTP ${upstream.status}）。` });
    }

    const reply = result?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return send(res, 502, { error: "AI 服务返回了空回答。" });
    }
    return send(res, 200, { reply: reply.trim() });
  } catch (error) {
    const message = error?.name === "TimeoutError"
      ? "AI 请求超时，请稍后重试。"
      : (error?.message || "服务器处理请求失败。");
    return send(res, 400, { error: message });
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`JARVIS backend listening on ${PORT}`);
});
