# JARVIS V1.1：真实 AI 对话接入

## 本阶段完成
- Android 聊天界面改为调用你自己的 HTTPS 后端
- 最近 12 条对话作为上下文发送
- 加载状态、连接错误提示
- 后端地址在 App 设置中填写并保存在本机
- APK 不保存 AI API Key；App 通过设置输入后端访问令牌
- 提供 Node.js 后端示例，后端再调用兼容 Chat Completions 接口的 AI 服务
- Android 端强制 HTTPS

## 重要：目前还不是开箱即用的在线 AI
你还需要一个部署在 HTTPS 地址上的后端，以及一个你有权使用的 AI 服务商账号和密钥。
本压缩包没有包含 API Key，也不会替你创建付费账号或服务器。

## 部署后端
需要 Node.js 20 或更新版本。推荐部署在你信任的云平台，并启用 HTTPS。
在 backend 目录：
1. 设置环境变量 AI_BASE_URL、AI_MODEL、AI_API_KEY、JARVIS_ACCESS_TOKEN。访问令牌应使用随机长字符串，并妥善保管。
2. `npm start`
3. 检查 `https://你的域名/health` 是否返回 `{"ok":true,...}`。
4. 确认 `https://你的域名/api/chat` 由 HTTPS 反向代理保护。
5. Android App 右上角设置中，填写 HTTPS 地址和同一个私人访问令牌。
5. 生产部署时增加身份认证、请求速率限制、用量限额和监控；当前示例后端是最小演示，不应未经加固直接公开部署。

## Android 运行
1. 用 Android Studio 打开项目根目录。
2. 等待 Gradle Sync。
3. Run 到模拟器或 Android 测试手机。
4. 在 JARVIS 右上角设置中填入后端 HTTPS 地址。
5. 发送一条普通问题测试。

## Android 端安全说明
- App 不要求通讯录、短信、相册、麦克风等权限。
- 仅有 INTERNET 权限。
- 不要将 API Key 写入 Android 源码或 BuildConfig。
- 只发送最近 12 条对话；用户输入仍会发送给所配置的后端和 AI 服务商。
- 清除 App 数据会清除本机保存的后端地址。

## 下一步建议
V1.2 再加入语音输入和语音播报；手机控制功能应在之后逐项加入，并由独立权限/确认层管理。
