# V1.1 代码可视化

```text
Android 手机
┌──────────────────────────────┐
│ MainActivity.kt              │
│  - 对话界面                   │
│  - 输入/发送                  │
│  - 加载与错误状态             │
│  - 后端地址设置               │
└──────────────┬───────────────┘
               │ HTTPS POST /api/chat
               ▼
┌──────────────────────────────┐
│ AiClient.kt                  │
│  - 最近 12 条消息             │
│  - 后端访问令牌               │
│  - HTTPS 检查                 │
│  - 请求/响应解析              │
└──────────────┬───────────────┘
               │
               ▼
        你的 HTTPS 后端
┌──────────────────────────────┐
│ backend/server.js            │
│  - 校验访问令牌               │
│  - 校验请求                   │
│  - 读取服务器环境变量密钥     │
│  - 调用 AI 服务商             │
│  - 只返回回答                 │
└──────────────┬───────────────┘
               │ HTTPS + 服务端密钥
               ▼
          AI 模型服务
```

## 关键文件
- `MainActivity.kt`：App UI 和交互状态
- `AiClient.kt`：Android 到后端的网络通信
- `AndroidManifest.xml`：只声明 INTERNET 权限
- `backend/server.js`：服务端代理，API Key 不进入 APK
- `backend/.env.example`：环境变量模板，不含真实密钥
