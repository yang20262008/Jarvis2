# JARVIS V1.3 架构

```text
文字 / 语音输入（输入框，可编辑）
        |  点击发送
        v
LocalCommands（本地指令解析，短句才触发）
   |-- 时间 / 电量 ----------> 直接回答（只读，不上传）
   |-- 打开应用 / 设置 / 拨号 --> 确认窗口 --确认--> startActivity
   |-- 操作记录 -------------> 记录窗口
   |-- 其他 -----------------> AiClient --HTTPS--> 私人后端 --> AI 模型
        |
        v
聊天界面（本机保存）--> TextToSpeech 播报
        |
所有操作 --> ActionLog（本机操作记录）
```

| 文件 | 作用 |
|---|---|
| MainActivity.kt | 界面、语音识别、播报、确认窗口、记录窗口、设置 |
| LocalCommands.kt | 本地指令解析与动作定义 |
| LocalStore.kt | 操作记录 ActionLog、对话记录 ChatStore |
| AiClient.kt | 后端通信、自动重试、连接测试 |
| backend/server.js | 令牌校验、限流、调用 AI |
